package ibis.deploy.monitoring.collection.exceptions;

public class UnknownAttributeException extends Exception {
	private static final long serialVersionUID = -5066235104732074426L;

}
