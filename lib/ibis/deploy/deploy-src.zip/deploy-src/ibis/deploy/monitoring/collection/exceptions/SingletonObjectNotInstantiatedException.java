package ibis.deploy.monitoring.collection.exceptions;

public class SingletonObjectNotInstantiatedException  extends Exception {
	private static final long serialVersionUID = -1149383567882656740L;
}
