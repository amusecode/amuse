package ibis.deploy.monitoring.collection.exceptions;

public class MetricNotAvailableException extends Exception {
	private static final long serialVersionUID = 3088477019116029367L;

}
