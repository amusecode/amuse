package ibis.deploy.monitoring.simulator;

public interface FakeService {
	public void doUpdate();
}
