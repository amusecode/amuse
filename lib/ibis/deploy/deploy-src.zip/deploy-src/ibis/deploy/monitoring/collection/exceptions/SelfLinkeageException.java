package ibis.deploy.monitoring.collection.exceptions;

public class SelfLinkeageException extends Exception {
	private static final long serialVersionUID = -665103073935348941L;

}
