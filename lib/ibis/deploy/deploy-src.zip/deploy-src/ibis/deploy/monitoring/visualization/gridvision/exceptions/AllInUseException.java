package ibis.deploy.monitoring.visualization.gridvision.exceptions;

public class AllInUseException extends Exception {
	private static final long serialVersionUID = 7889035026952604655L;

}
