package ibis.deploy.monitoring.collection.exceptions;

public class SourceNotProvidedException extends Exception {
	private static final long serialVersionUID = 5373864265987257879L;

}
