package ibis.deploy.gui;

public interface WorkSpaceChangedListener {

    public void workSpaceChanged(GUI gui);

}
