package ibis.deploy.gui.editor;

public interface EditorListener {

    public void edited(Object object);

}
